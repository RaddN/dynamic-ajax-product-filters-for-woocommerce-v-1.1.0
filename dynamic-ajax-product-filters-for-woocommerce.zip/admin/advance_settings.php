<?php
if (!defined('ABSPATH')) {
    exit;
}
// Render the "Product Selector" field
function dapfforwc_product_selector_callback()
{
    global $dapfforwc_advance_settings;
    $product_selector = isset($dapfforwc_advance_settings['product_selector']) ? esc_attr($dapfforwc_advance_settings['product_selector']) : '.products';
?>
    <input type="text" name="dapfforwc_advance_options[product_selector]" value="<?php echo esc_attr($product_selector); ?>" placeholder=".products">
    <p class="description">
        <?php esc_html_e('Enter the CSS selector for the product container. Default is .products.', 'dynamic-ajax-product-filters-for-woocommerce'); ?>
    </p>
<?php
}

// Render the "Pagination Selector" field
function dapfforwc_pagination_selector_callback()
{
    global $dapfforwc_advance_settings;
    $pagination_selector = isset($dapfforwc_advance_settings['pagination_selector']) ? esc_attr($dapfforwc_advance_settings['pagination_selector']) : '.woocommerce-pagination';
?>
    <input type="text" name="dapfforwc_advance_options[pagination_selector]" value="<?php echo esc_attr($pagination_selector); ?>" placeholder=".woocommerce-pagination">
    <p class="description">
        <?php esc_html_e('Enter the CSS selector for the pagination container. Default is .woocommerce-pagination.', 'dynamic-ajax-product-filters-for-woocommerce'); ?>
    </p>
<?php
}
// Render the "Product Shortcode Selector" field
function dapfforwc_product_shortcode_callback()
{
    global $dapfforwc_advance_settings;
    $product_shortcode = isset($dapfforwc_advance_settings['product_shortcode']) ? esc_attr($dapfforwc_advance_settings['product_shortcode']) : 'products';
?>
    <input type="text" name="dapfforwc_advance_options[product_shortcode]" value="<?php echo esc_attr($product_shortcode); ?>" placeholder="products">
    <p class="description">
        <?php esc_html_e('Enter the selector for the products shortcode. Default is products', 'dynamic-ajax-product-filters-for-woocommerce'); ?>
    </p>
<?php
}

function dapfforwc_text_manage_render()
{
    global $dapfforwc_advance_settings;
    $no_products_text = isset($dapfforwc_advance_settings['no_products_text']) && $dapfforwc_advance_settings['no_products_text'] !== '' ? $dapfforwc_advance_settings['no_products_text'] : 'No products were found matching your selection.';
    $select2_placeholder = isset($dapfforwc_advance_settings['select2_placeholder']) && $dapfforwc_advance_settings['select2_placeholder'] !== '' ? $dapfforwc_advance_settings['select2_placeholder'] : 'Select Options';
    ?>
    <div style="max-width: 500px;">
        <label for="dapfforwcpro-no-products-text" style="font-weight: 600; display:block; margin-bottom:4px;"><?php esc_html_e('No products message', 'dynamic-ajax-product-filters-for-woocommerce'); ?></label>
        <input type="text" id="dapfforwcpro-no-products-text" name="dapfforwc_advance_options[no_products_text]" value="<?php echo esc_attr($no_products_text); ?>" class="regular-text" placeholder="No products were found matching your selection.">
        <p class="description"><?php esc_html_e('Shown when a filter results in zero products.', 'dynamic-ajax-product-filters-for-woocommerce'); ?></p>

        <label for="dapfforwcpro-select2-placeholder" style="font-weight: 600; display:block; margin:14px 0 4px;"><?php esc_html_e('Select2 dropdown placeholder', 'dynamic-ajax-product-filters-for-woocommerce'); ?></label>
        <input type="text" id="dapfforwcpro-select2-placeholder" name="dapfforwc_advance_options[select2_placeholder]" value="<?php echo esc_attr($select2_placeholder); ?>" class="regular-text" placeholder="Select Options">
        <p class="description"><?php esc_html_e('Default placeholder text for Select2 dropdowns.', 'dynamic-ajax-product-filters-for-woocommerce'); ?></p>
    </div>
    <?php
}

function dapfforwc_remove_outofStock_render()
{
    dapfforwc_render_advance_checkbox('remove_outofStock', esc_html__('Enable this option to remove out-of-stock products from the filter results.', 'dynamic-ajax-product-filters-for-woocommerce'));
}
function dapfforwc_wait_cursor_on_filtering_render()
{
    dapfforwc_render_advance_checkbox('wait_cursor_on_filtering', esc_html__('Show the browser wait cursor while filters are loading new products.', 'dynamic-ajax-product-filters-for-woocommerce'));
}
function dapfforwc_use_overlay_render()
{
    dapfforwc_render_advance_checkbox('use_overlay', esc_html__('Display a page overlay during AJAX filtering requests.', 'dynamic-ajax-product-filters-for-woocommerce'));
}
function dapfforwc_smart_auto_scroll_render()
{
    dapfforwc_render_advance_checkbox('smart_auto_scroll', esc_html__('Automatically scroll to the product grid after AJAX updates and enable scroll-based pagination helpers.', 'dynamic-ajax-product-filters-for-woocommerce'));
}
function dapfforwc_pagination_via_ajax_render()
{
    dapfforwc_render_advance_checkbox('pagination_via_ajax', esc_html__('Load pagination links through AJAX instead of a full page reload.', 'dynamic-ajax-product-filters-for-woocommerce'));
}
function dapfforwc_sorting_via_ajax_render()
{
    dapfforwc_render_advance_checkbox('sorting_via_ajax', esc_html__('Apply WooCommerce product sorting with AJAX instead of a full page reload.', 'dynamic-ajax-product-filters-for-woocommerce'));
}
function dapfforwc_allow_data_share_render()
{
    dapfforwc_render_advance_checkbox('allow_data_share', esc_html__('We collect non-sensitive technical details from your website, like the PHP version and features usage, to help us troubleshoot issues faster, make informed development decisions, and build features that truly benefit you.', 'dynamic-ajax-product-filters-for-woocommerce') . " <a href='https://plugincy.com/usage-tracking/' target='_blank'>". esc_html__('Learn more…', 'dynamic-ajax-product-filters-for-woocommerce')."</a>");
}
function dapfforwc_side_bar_top_render()
{
    dapfforwc_render_advance_checkbox('sidebar_on_top', esc_html__('For mobile move the sidebar to top position.', 'dynamic-ajax-product-filters-for-woocommerce'));
}
function dapfforwc_mobile_breakpoint_render()
{
    global $dapfforwc_advance_settings;
    $mobile_breakpoint = isset($dapfforwc_advance_settings['mobile_breakpoint']) ? absint($dapfforwc_advance_settings['mobile_breakpoint']) : 768;
    ?>
    <input type="number" name="dapfforwc_advance_options[mobile_breakpoint]" value="<?php echo esc_attr($mobile_breakpoint); ?>" min="320" step="1" placeholder="768">
    <p class="description">
        <?php esc_html_e('Set the maximum viewport width (in pixels) where mobile-specific filter behavior should apply.', 'dynamic-ajax-product-filters-for-woocommerce'); ?>
    </p>
    <?php
}
function dapfforwc_default_value_selected_render()
{
    dapfforwc_render_advance_checkbox('default_value_selected', esc_html__('Make default value from shortcode & pages selected/checked', 'dynamic-ajax-product-filters-for-woocommerce'));
}


function dapfforwc_render_advance_checkbox($key, $message = null)
{
    global $dapfforwc_allowed_tags;
    global $dapfforwc_advance_settings;
?>
    <label class="switch <?php echo esc_attr($key); ?> <?php echo $key === 'wait_cursor_on_filtering' || $key === 'use_overlay' || $key === 'smart_auto_scroll' || $key === 'pagination_via_ajax' || $key === 'sorting_via_ajax' ? 'pro-only' : ''; ?>">
        <input <?php echo $key === 'wait_cursor_on_filtering' || $key === 'use_overlay' || $key === 'smart_auto_scroll' || $key === 'pagination_via_ajax' || $key === 'sorting_via_ajax' ? 'disabled' : ''; ?> type='checkbox' name='dapfforwc_advance_options[<?php echo esc_attr($key); ?>]' <?php checked(isset($dapfforwc_advance_settings[$key]) && $dapfforwc_advance_settings[$key] === "on"); ?>>
        <span class="slider round"></span>
        <span class="switch-on">On</span>
        <span class="switch-off">Off</span>
    </label>
    <?php
    if (isset($message) && !empty($message)) {
        echo "<p class='description' style='max-width: 800px;'>" . wp_kses($message, $dapfforwc_allowed_tags) . "</p>";
    }
}

function dapfforwc_exclude_attributes_render()
{
    global $dapfforwc_advance_settings;
    $exclude_attributes = isset($dapfforwc_advance_settings['exclude_attributes']) ? explode(',', $dapfforwc_advance_settings['exclude_attributes']) : []; // Convert string to array
    $all_data = dapfforwc_get_woocommerce_attributes_with_terms();
    $all_attributes = isset($all_data['attributes']) ? $all_data['attributes'] : [];
    $dapfforwc_attributes = [];
    
    foreach ($all_attributes as $attribute) {
        $dapfforwc_attributes[] = (object) [
            'attribute_name' => $attribute['attribute_name'],
            'attribute_label' => $attribute['attribute_label'],
        ];
    }
    ?>
    <select class="plugincy_select2" id="exclude-attributes" name="dapfforwc_advance_options[exclude_attributes][]" multiple style="scrollbar-width: thin;min-width: 141px;" data-placeholder="<?php esc_html_e('Select Attributes to Exclude', 'dynamic-ajax-product-filters-for-woocommerce'); ?>">
        <?php foreach ($dapfforwc_attributes as $option) : ?>
            <option value="<?php echo esc_attr($option->attribute_name); ?>" 
                <?php echo in_array($option->attribute_name, $exclude_attributes) ? 'selected' : ''; ?>>
                <?php echo esc_html($option->attribute_label); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <?php
}
function dapfforwc_exclude_custom_fields_render()
{
    global $dapfforwc_advance_settings;
    $exclude_custom_fields = isset($dapfforwc_advance_settings['exclude_custom_fields']) ? explode(',', $dapfforwc_advance_settings['exclude_custom_fields']) : []; // Convert string to array
    $all_data = dapfforwc_get_woocommerce_attributes_with_terms();
    $custom_fields = isset($all_data['custom_fields']) ? $all_data['custom_fields'] : [];
    $dapfforwc_attributes = [];
    
    foreach ($custom_fields as $attribute) {
        $dapfforwc_attributes[] = (object) [
            'attribute_name' => $attribute['name'],
            'attribute_label' => $attribute['label'],
        ];
    }
    ?>
    <div class="pro-only">
        <select class="plugincy_select2" disabled id="exclude_custom_fields" name="dapfforwc_advance_options[exclude_custom_fields][]" multiple style="scrollbar-width: thin;min-width: 141px;" data-placeholder="<?php esc_html_e('Select Custom Fields to Exclude', 'dynamic-ajax-product-filters-for-woocommerce'); ?>">
            <?php foreach ($dapfforwc_attributes as $option) : ?>
                <option value="<?php echo esc_attr($option->attribute_name); ?>" 
                    <?php echo in_array($option->attribute_name, $exclude_custom_fields) ? 'selected' : ''; ?>>
                    <?php echo esc_html($option->attribute_label); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php
}
